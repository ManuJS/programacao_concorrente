// Classe Principal.java
// mostra duas threads modificando um objeto compartilhado.

public class Principal {

   // execute application
   public static void main( String args[] )
   {
      ObjetoBuffer umBuffer = new ObjetoBuffer();

      // criacao das threads
      Produtor umProdutor =  new Produtor( umBuffer );
      Consumidor umConsumidor = new Consumidor( umBuffer);

      // start threads
      umProdutor.start();
      umConsumidor.start();
   }

}  // fim da classe Principal

