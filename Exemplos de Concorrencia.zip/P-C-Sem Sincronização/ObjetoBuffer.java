// Classe ObjetoBuffer.java

public class ObjetoBuffer {
   private int memoria = -1;

   // metodo de escrita de dados na memoria
   public void escreveBuffer( int valor )
   {
      System.err.println( Thread.currentThread().getName() +
         " produzindo o valor: " + valor );

      this.memoria = valor;
   }

   // metodo de leitura de dados na memoria
   public int lerBuffer()
   {
      System.err.println( Thread.currentThread().getName() +
         " consumindo o valor: " + this.memoria );

      return this.memoria;
   }

} 

// fim da classe ObjetoBuffer

