// Classe Consumidor.java

public class Consumidor extends Thread {
   private ObjetoBuffer um_Buffer;

   // Construtor do Consumidor thread object
   public Consumidor( ObjetoBuffer dado )
   {
      super( &quot;Consumidor&quot; );
      um_Buffer = dado;
   }

   // Thread Consumidor lerah o buffer 10 vezes em intervalos aleatorios
   
   public void run()
   {
      int valor, soma = 0;

      do {

         // dorme por um intervalo aleatorio
         try {
            Thread.sleep( (int) ( Math.random() * 3000 ) );
         }

         // Tratamento de excecao
         catch( InterruptedException exception ) {
            System.err.println( exception.toString() );
         }

         valor = um_Buffer.lerBuffer();
         soma += valor;

      } while ( valor != 10 );

      System.err.println(
         getName() + &quot; terminou de consumir. Totalizou: &quot; + soma);
   }

} 

// fim da classe Consumidor</pre></tt></td></tr></table>
</body></html>
