// classe Produtor.java
// Definicao da classe Produtor

public class Produtor extends Thread {
   private  ObjetoBuffer o_Buffer;

   // construtor da Thread Produtor
   public Produtor( ObjetoBuffer dado )
   {
      super( &quot;Produtor&quot; );
      o_Buffer = dado;
   }

   // Thread do Produtor escreverah 10 vezes no buffer em intervalos de tempo
aleatorios 
   
   public void run()
   {
      for ( int i = 1; i &lt;= 10; i++ ) {

         // dorme por um tempo aleatorio
         try {
            Thread.sleep( ( int ) ( Math.random() * 3000 ) );
         }

         // tratamento de excecao
         catch( InterruptedException exception ) {
            System.err.println( exception.toString() );
         }

         // chama metodo do objeto buffer 
         
         o_Buffer.escreveBuffer( i );
      }

      System.err.println(getName() + &quot; terminou de produzir&quot;);
   }

}  
// FIM DA CLASSE Produtor
