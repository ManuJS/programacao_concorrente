// Classe ObjetoBuffer.java

public class ObjetoBuffer {
   private int memoria = -1;

   // metodo de escrita de dados na memoria
   public void escreveBuffer( int valor )
   {
      System.err.println( Thread.currentThread().getName() +
         &quot; prodizindo o valor: &quot; + valor );

      this.memoria = valor;
   }

   // metodo de leitura de dados na memoria
   public int lerBuffer()
   {
      System.err.println( Thread.currentThread().getName() +
         &quot; consumindo o valor: &quot; + this.memoria );

      return this.memoria;
   }

} 

// fim da classe ObjetoBuffer

