
import java.util.concurrent.*;

public class CountdownThread extends Thread {
    
    private static long tempo = 0, contagem = 10, espera = 5, intervalo = 1;
    
    public CountdownThread (long tempo) {
        this.tempo = tempo;
    }
   
    public void run() {
        System.out.println("Faltam "+ tempo +" segundos para o encerramento.");
        tempo--;
    }
    
    public static void main(String args[]) {
        ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor(); 
        System.out.println("A contagem iniciar� em "+ espera + " segundos.");
        exec.scheduleAtFixedRate(new CountdownThread(contagem), espera, intervalo, TimeUnit.SECONDS);
        try {
            exec.awaitTermination(espera + contagem, TimeUnit.SECONDS);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        }
        exec.shutdown();  
        System.out.println("Programa encerrado.");
    }      
}
