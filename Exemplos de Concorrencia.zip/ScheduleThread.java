/*
 * ScheduleTest.java
 *
 * Created on 15 de Fevereiro de 2006, 16:52
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
import java.util.concurrent.*;
/**
 *
 * @author Frank
 */
public class ScheduleThread extends Thread {
      
    public void run() {
        System.out.println(getName() + " executada.");
    }
    
    public static void main(String args[]) {
        ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor(); 
        
        for (int i=0; i<10; i++) {
            long tempo = (long) (Math.random()*10000);
            System.out.println("Thread-" + i + " ser� executada em "+ tempo + "ms.");
            exec.schedule(new ScheduleThread(), tempo, TimeUnit.MILLISECONDS);
        }
        exec.shutdown();
    }
}
