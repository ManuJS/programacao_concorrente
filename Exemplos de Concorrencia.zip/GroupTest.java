

public class GroupTest {
    public static void main(String args[]) {
        ThreadGroup group = new ThreadGroup("Sleepers"); // Cria grupo
        for (int i=0; i<10; i++) {
            new Thread(group,"Sleeper"+i) {
                public void run() {
                    System.out.println(getName() + " iniciada.");
                    try {
                        sleep(10000);
                    } catch (InterruptedException ie) {
                        System.out.println(getName() + " interrompida.");
                    }
                }
            }.start();
        }
        try {
            Thread.sleep(5000);
        } catch (InterruptedException ie) {}
        group.interrupt(); // Interrompe todas as threads do grupo
    }
}