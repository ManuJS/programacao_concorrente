/*
 * ThreadSleep.java
 *
 * Created on 15 de Fevereiro de 2006, 16:19
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author Frank adaptado de Deitel - Java: Como Programar
 */
public class ThreadSleep extends Thread {
    
    private long tempo = 0;
    
    public ThreadSleep(long tempo) {
        this.tempo = tempo;
    }
    
    public void run() {
        System.out.println(getName() + " vai dormir por " + tempo + " ms.");
        try {
            sleep(tempo);
            System.out.println(getName() + " acordou.");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String args[]) {
        for (int i=0; i<10; i++)
            // Cria e executa as Threads
            new ThreadSleep((long)(Math.random() * 10000)).start();
    }
}
