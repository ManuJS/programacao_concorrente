/*
 * ThreadLocalTest.java
 *
 * Created on 16 de Fevereiro de 2006, 10:18
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author Frank
 */
public class ThreadLocalTest extends Thread {
    static ThreadLocal valorLocal = new ThreadLocal();
    static int contador = 0;
    public void run() {
        System.out.println(getName() + ": valorLocal = " + contador);
        valorLocal.set(new Integer(contador++));
        try {
            sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int valor = ((Integer)valorLocal.get()).intValue();
        System.out.println(getName() + ": valorLocal = " + valor);
    }
    public static void main (String args[]) {
        for (int i =0; i<10; i++)
            new ThreadLocalTest().start();
    }
}
