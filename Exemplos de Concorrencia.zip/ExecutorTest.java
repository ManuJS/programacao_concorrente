

import java.util.concurrent.*;


public class ExecutorTest {
    public static void main(String args[]) {
        ExecutorService exec = Executors.newFixedThreadPool(10);
        
        for (int i=0; i<10; i++) {
            exec.execute(new ThreadSleep((long)(Math.random()*10000))); // Cria e executa threads
        }
        exec.shutdown(); //  Encerra o servi�o quando threads acabarem
    }
}
